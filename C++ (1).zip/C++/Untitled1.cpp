#include <iostream>
using namespace std;
void f(int i)){
	if (i =4 || i=5) cout << "heloo";
}
int main() {
	f(3);
	
	return 0;
}
