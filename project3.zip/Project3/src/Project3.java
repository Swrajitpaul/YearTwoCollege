import java.text.DecimalFormat;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;
public class Project3 {
	public static double totalPurchase;
	public static Database file;
	public static Receipt transaction, gui;
	
	public static void main(String[] args) {
		gui = new Receipt("Project 3");
	}
	public void transcript(String file){
	String[] info = new String[100];
	info[0] = "Name"+":               "+ "Price"+ " * "+ "Weight" + " = " + "Total";
	TextFileInput purchase = new TextFileInput(file);
	int arrC = 1;
	StringTokenizer buy;
	for(int i=0; i<100; i++){
		 String line = purchase.readLine();
		 if (line == null){
	    	 break;
	     }
		 buy= new StringTokenizer(line, ",");
	     while (buy.hasMoreTokens()){
	    	 info[arrC]=item(buy.nextToken(), buy.nextToken());
	    	 arrC +=1;
	     }
	}
	DecimalFormat dt = new DecimalFormat("#.##");
	String totalPrice = dt.format(totalPurchase);
	
	transaction = new Receipt(info,arrC,totalPrice);
	}
	/**
	 * 
	 * @param num  takes in the code of the produce
	 * @param w  take in the weight of purchased produce
	 * @return String returns the name, price, weight and total value 
	 */
	public static String item (String num, String w){
		String name = " "; 
		float price;
		String number = num;
		 float weight = Float.parseFloat(w);
		 
		 try {
			 name = file.getName(number);
		 }
		 catch (ItemNotFoundException abc){
			 name = JOptionPane.showInputDialog("EXCEPTION: Name not found! \n Enter the produce name:");
		 }
		 
		 try {
			 price= file.getPrice(number);
		 }
		 catch(ItemNotFoundException error){
				String digits = JOptionPane.showInputDialog("EXCEPTION! Price not found! \n Enter the produce price:");
				price = Float.parseFloat(String.valueOf(digits));
		 }
		 
		 float total = price*weight;
		 double d = ((double)total);
		 DecimalFormat ddf = new DecimalFormat("#.##");
		 totalPurchase += d;
		 String returnLine = name + ":           $" + price + " * " + weight + "lb = $" + (ddf.format(d));
		 
		 return returnLine;
	}
		
		

}
