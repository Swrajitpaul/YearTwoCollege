
public class ProjectNode {
	public String data;
    public ProjectNode next;
 
    /**
     * 
     * @param d takes in a String and assigns it to data
     */
    public ProjectNode(String d){
      data = d;
      next = null;
   }  
}  
